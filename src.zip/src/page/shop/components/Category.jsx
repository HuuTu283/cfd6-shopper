
import { NavLink } from 'react-router-dom';

export default function Category({ title, slug }) {
    return (


        <li className="list-styled-item">
            <NavLink className="list-styled-link" to={slug}>
                {title}
            </NavLink>
        </li>
    )
}
